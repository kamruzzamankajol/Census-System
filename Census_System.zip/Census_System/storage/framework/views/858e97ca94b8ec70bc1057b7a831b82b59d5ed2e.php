<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-2">
          <?php echo $__env->make('layouts.side_navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-10 panel panel-default">
        	<h3>HOUSE-HOLD  <span style="font-size:15px; background-color: #546716;padding: 10px;border-radius: 50%;"><a style="cursor: pointer;" onclick="event.preventDefault(); document.getElementById('main_part').style.display='none';document.getElementById('edit_part').style.display='block';">Edit</a></span></h3><hr>
        	<style type="text/css">
            td{padding: 10px;text-align: right;}
            .align_left{text-align: left;}
           </style>
        	<div id="main_part">
        		<div class="col-md-6">
        			<table>
        			<tr>
        				<td>House : </td>
        				<td class="align_left"><?php echo e($data->house_own_type); ?></td>
        			</tr><tr>
        				<td>House wall : </td>
        				<td class="align_left"><?php echo e($data->house_wall); ?></td>
        			</tr><tr>
        				<td>Latrine : </td>
        				<td class="align_left"><?php echo e($data->latrin_type); ?></td>
        			</tr><tr>
        				<td>Total Land : </td>
        				<td class="align_left"><?php echo e($data->total_land); ?></td>
        			</tr>
        		</table>
        		</div>
        		<div class="col-md-6">
        			<table>
        			<tr>
        				<td>Source of Water : </td>
        				<td class="align_left"><?php echo e($data->source_of_water); ?></td>
        			</tr><tr>
        				<td>Occupation : </td>
        				<td class="align_left"><?php echo e($data->occupation); ?></td>
        			</tr><tr>
        				<td>Number of Person in Abroad : </td>
        				<td class="align_left"><?php echo e($data->number_of_person_in_abroad); ?></td>
        			</tr><tr>
        				<td style="padding-bottom: 30px;">Electricity : </td>
        				<td class="align_left"><?php echo e($data->electricity); ?></td>
        			</tr>
        		</table>
        		</div>		
        	</div>
        	<div id="edit_part" style="display: none;">
        		<div class="row">
        		   <form class="form-horizontal" method="POST" action="<?php echo e(route('update_house_hold')); ?>" id="edit_form">
                  <?php echo e(csrf_field()); ?>

                  <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                    <div class="col-md-3">
                        <div class="household_first">

                            <h1>House</h1>
                            <?php  $houses=['Own','Leaseholder','Homeless']  ?>
                            <?php $__currentLoopData = $houses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $house): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            	<label class="container">
                                    <input type="radio" name="house_own_type" value="<?php echo e($house); ?>" <?php if($data->house_own_type == $house): ?> checked <?php endif; ?> > <span class="checkmark"><?php echo e($house); ?></span> </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                

                                <h1>House wall</h1>
                                <?php  $house_walls=['Brick','Bamboo','Tin','Others']  ?>
                                <?php $__currentLoopData = $house_walls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $house_wall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="container">
                                    <input type="radio" name="house_wall" value="<?php echo e($house_wall); ?>" <?php if($data->house_wall==$house_wall): ?> checked <?php endif; ?>> <span class="checkmark"><?php echo e($house_wall); ?></span> </label>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="household_second">

                            <h1>Latrine</h1>
                             <?php  $latrines=['Sanitary','Paka-Sanitary','Un-sanitary']  ?>
                             <?php $__currentLoopData = $latrines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latrine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="container">
                                <input type="radio" name="latrin_type" value="<?php echo e($latrine); ?>"  <?php if($latrine == $data->latrin_type): ?> checked <?php endif; ?>> <span class="checkmark" ><?php echo e($latrine); ?></span> </label>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <h1>Total Land</h1>
                            <?php  $lands=['No Land','Below One-Akor','One-Akor','OverOne-akor']  ?>
                            <?php $__currentLoopData = $lands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $land): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="container">
                                <input type="radio" name="total_land" value="<?php echo e($land); ?>" <?php if($land==$data->total_land): ?> checked <?php endif; ?>> <span class="checkmark"><?php echo e($land); ?></span> </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="household_third">

                            <h1>Source of Water</h1>
                            <?php  $water_sources=['Suplay','Tube-well','Others']  ?>
                            <?php $__currentLoopData = $water_sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $water_source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="container">
                                <input type="radio" name="source_of_water" value="<?php echo e($water_source); ?>" <?php if($water_source==$data->source_of_water): ?> checked <?php endif; ?>> <span class="checkmark"><?php echo e($water_source); ?></span> </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <h1>Occupation</h1>
                            <?php  $occupations=['Farming','Business','Politician','Educational']  ?>
                            <?php $__currentLoopData = $occupations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occupation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="container">
                                <input type="radio" name="farming" value="<?php echo e($occupation); ?>" <?php if($occupation==$data->occupation): ?> checked <?php endif; ?>> <span class="occupation"><?php echo e($occupation); ?></span> </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="household_forth">

                            <h1>Number of Person in Abroad</h1>
                            <?php  $abroad_persons=['One','Two','Three','Four']  ?>
                            <?php $__currentLoopData = $abroad_persons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abroad_person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="container">
                                <input type="radio" name="number_of_person_in_abroad" value="<?php echo e($abroad_person); ?>" <?php if($abroad_person==$data->number_of_person_in_abroad): ?> checked <?php endif; ?>> <span class="checkmark"><?php echo e($abroad_person); ?></span> </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <h1>Electricity</h1>
                            <?php  $electricitys=['Yes','No']  ?>
                            <?php $__currentLoopData = $electricitys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $electricity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="container">
                                <input type="radio" name="electricity" value="<?php echo e($electricity); ?>" <?php if($electricity==$data->electricity): ?> checked <?php endif; ?>> <span class="checkmark"><?php echo e($electricity); ?></span> </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                    <div class="col-md-10"></div>
                    <div class="col-md-2" style="margin-top: 15px;margin-bottom: 15px;">
                    	<input type="submit" class="btn btn-lg btn-primary" value="Submit">
                    </div>
                </form>
                </div>
        	</div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>