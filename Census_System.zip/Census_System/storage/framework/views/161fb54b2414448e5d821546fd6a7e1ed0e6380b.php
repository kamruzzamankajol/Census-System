  <div class="panel panel-default">
            <nav id="sidebar">
             <ul class="list-unstyled components">
                <li> <a href="<?php echo e(url('home')); ?>"><i class="fa fa-university" aria-hidden="true"></i> Home</a> </li> 
                <li> <a href="<?php echo e(url('house_hold')); ?>"><i class="fa fa-university" aria-hidden="true"></i> HOUSE-HOLD</a> </li> 
                <li> <a href="<?php echo e(url('member')); ?>"><i class="fa fa-university" aria-hidden="true"></i> Member</a> </li> 
            </ul>
            </nav>
</div>