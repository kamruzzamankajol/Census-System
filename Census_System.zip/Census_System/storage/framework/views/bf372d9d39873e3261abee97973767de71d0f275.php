<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-2">
          <?php echo $__env->make('layouts.side_navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <style type="text/css">
            td{padding: 10px;text-align: right;}
            .align_left{text-align: left;}
        </style>
        <div class="col-md-10 panel panel-default" >
                <?php  $i=0;  ?> 

                <div class="col-md-6"><h3>Permanent Address <span style="font-size:15px; background-color: #546716;padding: 10px;border-radius: 50%;"><a style="cursor: pointer;" onclick="event.preventDefault(); document.getElementById('main_part').style.display='none';document.getElementById('edit_part').style.display='block';">Edit</a></span></h3><hr></div>
                <div class="col-md-6"><h3>Present Address <span style="font-size:15px; background-color: #546716;padding: 10px;border-radius: 50%;"><a style="cursor: pointer;" onclick="event.preventDefault(); document.getElementById('main_part').style.display='none';document.getElementById('edit_part').style.display='block';">Edit</a></span></h3><hr></div>
                
                
                <div id="main_part">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                <table >
                    <tr>
                        <td>House Name/no :</td>
                        <td class="align_left"><?php echo e($value->house_name_no); ?></td>
                    </tr>
                    <tr>
                        <td>Road Name/no :</td>
                        <td class="align_left"><?php echo e($value->road_name_no); ?></td>
                    </tr> <tr>
                        <td>Village Name :</td>
                        <td class="align_left"><?php echo e($value->village_name); ?></td>
                    </tr><tr>
                        <td>Union :</td>
                        <td class="align_left"><?php echo e($value->union); ?></td>
                    </tr><tr>
                        <td>Post Code :</td>
                        <td class="align_left"><?php echo e($value->post_code); ?></td>
                    </tr><tr>
                        <td>Thana Name :</td>
                        <td class="align_left"><?php echo e($value->thana_name); ?></td>
                    </tr><tr>
                        <td style="padding-bottom: 30px;">District Name :</td>
                        <td class="align_left"><?php echo e($value->district); ?></td>
                    </tr>
                </table>
                </div>
                <?php  $i++;  ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($i == 0): ?>
                <?php for($i=0;$i<2;$i++): ?>
                <div class="col-md-6">
                  <table >
                    <tr>
                        <td>House Name/no :</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Road Name/no :</td>
                        <td></td>
                    </tr> <tr>
                        <td>Village Name :</td>
                        <td></td>
                    </tr><tr>
                        <td>Union :</td>
                        <td></td>
                    </tr><tr>
                        <td>Post Code :</td>
                        <td></td>
                    </tr><tr>
                        <td>Thana Name :</td>
                        <td></td>
                    </tr><tr>
                        <td style="padding-bottom: 30px;">District Name :</td>
                        <td></td>
                    </tr>
                </table>  
                </div>
                <?php endfor; ?>
                <?php endif; ?>
            </div>
            
            <div id="edit_part" style="display: none;">
                <form class="form-horizontal" method="POST" action="<?php echo e(route('create_address')); ?>" id="edit_form">
                  <?php echo e(csrf_field()); ?>

                 <?php  $i=1;  ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                    <input type="hidden" name="id<?php echo e($i); ?>" value="<?php echo e($value->id); ?>">
                <table >
                    <?php if($i==2): ?>
                    <tr>
                        <td>
                            <input type="checkbox" name="" id="same_as" class="form-control" onclick="Same_As();">
                        </td>
                        <td style="text-align: left;">Same As Permanent Address </td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                        <td>House Name/no :</td>
                        <td><input type="text" class="form-control" id="houseno<?php echo e($i); ?>" name="house_name_no<?php echo e($i); ?>" placeholder="Enter houseno or name" value="<?php echo e($value->house_name_no); ?>"></td>
                    </tr>
                    <tr>
                        <td>Road Name/no :</td>
                        <td><input type="text" class="form-control" id="roadno<?php echo e($i); ?>" name="road_name_no<?php echo e($i); ?>" placeholder="Enter road no or name" value="<?php echo e($value->road_name_no); ?>"></td>
                    </tr> <tr>
                        <td>Village Name :</td>
                        <td><input type="text" class="form-control" id="village<?php echo e($i); ?>" name="village_name<?php echo e($i); ?>" placeholder="Enter Village name" value="<?php echo e($value->village_name); ?>"></td>
                    </tr><tr>
                        <td>Union :</td>
                        <td><input type="text" class="form-control" id="unionno<?php echo e($i); ?>" name="union<?php echo e($i); ?>" placeholder="Enter Union name" value="<?php echo e($value->union); ?>"></td>
                    </tr><tr>
                        <td>Post Code :</td>
                        <td><input type="text" class="form-control" id="postcode<?php echo e($i); ?>" name="post_code<?php echo e($i); ?>" placeholder="Enter post code " value="<?php echo e($value->post_code); ?>"></td>
                    </tr><tr>
                        <td>Thana Name :</td>
                        <td><input type="text" class="form-control" id="thana<?php echo e($i); ?>" name="thana_name<?php echo e($i); ?>" placeholder="Enter thana name" value="<?php echo e($value->thana_name); ?>"></td>
                    </tr><tr>
                        <td>District Name :</td>
                        <td><input type="text" class="form-control" id="district<?php echo e($i); ?>" name="district<?php echo e($i); ?>" placeholder="Enter district name" value="<?php echo e($value->district); ?>"></td>
                    </tr>
                </table> </div>
                <?php  $i++;  ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               <?php if($i==1): ?>
               <?php for($i=1;$i<3;$i++): ?>
               <div class="col-md-6">
                <input type="hidden" name="id<?php echo e($i); ?>" value="0">
                    <table >
                        <?php if($i==2): ?>
                    <tr>
                        <td>
                            <input type="checkbox" name="" id="same_as" class="form-control" onclick="Same_As()">
                        </td>
                        <td style="text-align: left;">Same As Permanent Address </td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                        <td>House Name/no :</td>
                        <td><input type="text" class="form-control" id="houseno<?php echo e($i); ?>" name="house_name_no<?php echo e($i); ?>" placeholder="Enter houseno or name" value=""></td>
                    </tr>
                    <tr>
                        <td>Road Name/no :</td>
                        <td><input type="text" class="form-control" id="roadno<?php echo e($i); ?>" name="road_name_no<?php echo e($i); ?>" placeholder="Enter road no or name" value=""></td>
                    </tr> <tr>
                        <td>Village Name :</td>
                        <td><input type="text" class="form-control" id="village<?php echo e($i); ?>" name="village_name<?php echo e($i); ?>" placeholder="Enter Village name" value=""></td>
                    </tr><tr>
                        <td>Union :</td>
                        <td><input type="text" class="form-control" id="unionno<?php echo e($i); ?>" name="union<?php echo e($i); ?>" placeholder="Enter Union name" value=""></td>
                    </tr><tr>
                        <td>Post Code :</td>
                        <td><input type="text" class="form-control" id="postcode<?php echo e($i); ?>" name="post_code<?php echo e($i); ?>" placeholder="Enter post code " value=""></td>
                    </tr><tr>
                        <td>Thana Name :</td>
                        <td><input type="text" class="form-control" id="thana<?php echo e($i); ?>" name="thana_name<?php echo e($i); ?>" placeholder="Enter thana name" value=""></td>
                    </tr><tr>
                        <td>District Name :</td>
                        <td><input type="text" class="form-control" id="district<?php echo e($i); ?>" name="district<?php echo e($i); ?>" placeholder="Enter district name" value=""></td>
                    </tr>
                </table>
               </div>
               <?php endfor; ?> 
               <?php endif; ?>

               <div class="col-md-10"></div>
               <div class="col-md-2">
                   <input type="submit" style="margin-bottom: 15px;" name="submit_address" value="Submit" class="btn btn-lg btn-primary">
               </div>              
           </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script type="text/javascript">
    function Same_As() {
       var edit_form=document.getElementById('edit_form');
       edit_form.house_name_no2.value=edit_form.house_name_no1.value;
       edit_form.road_name_no2.value=edit_form.road_name_no1.value;
       edit_form.village_name2.value=edit_form.village_name1.value;
       edit_form.union2.value=edit_form.union1.value;
       edit_form.post_code2.value=edit_form.post_code1.value;
       edit_form.thana_name2.value=edit_form.thana_name1.value;
       edit_form.district2.value=edit_form.district1.value;
    }
</script>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>