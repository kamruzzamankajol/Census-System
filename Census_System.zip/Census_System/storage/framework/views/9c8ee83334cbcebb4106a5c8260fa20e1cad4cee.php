<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-2">
          <?php echo $__env->make('layouts.side_navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-10 panel panel-default" style="padding: 10px">
        	<h3>Edit Member Details</h3><hr>
        	<form class="form-horizontal" method="POST" action="<?php echo e(route('update_member')); ?>" id="edit_form">
                  <?php echo e(csrf_field()); ?>

                  <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
        	<div class="row">
                <div class="col-md-5">
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="number">NID:</label>
                                <div class="col-sm-10">
                                    <input type="number" name="nid" class="form-control" id="NID" placeholder="Enter NID" value="<?php echo e($data->nid); ?>"> </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="BID">BID:</label>
                                <div class="col-sm-10">
                                    <input type="number" name="bid" class="form-control" id="BID" placeholder="Enter BID" value="<?php echo e($data->bid); ?>"> </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="name">Name:</label>
                                <div class="col-sm-10">
                                    <input type="text" name="name" class="form-control" id="name" placeholder="Enter your full name" value="<?php echo e($data->name); ?>"> </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="date">Birth Date:</label>
                                <div class="col-sm-10">
                                    <input type="date" name="birth_date" class="form-control" id="date" placeholder="date " value="<?php echo e($data->birth_date); ?>"> </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="Occupation">Occupation:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="Occupation" name="occupation" placeholder="Enter your Occupation" value="<?php echo e($data->occupation); ?>"> </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="Education">Education:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="Education" name="education" placeholder="Enter highest Education" value="<?php echo e($data->education); ?>"> </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="Education">Relation W khana:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="Relation" name="relation_with_khana" placeholder="Relation with khana" value="<?php echo e($data->relation_with_khana); ?>"> </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="Education">Present Address:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="Relation" name="present_address" placeholder="Villege,union,Thana,District" value="<?php echo e($data->present_address); ?>"> </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="Education">Mob. Number:</label>
                                <div class="col-sm-10">
                                    <input type="number" name="mobile_no" class="form-control" id="Relation" placeholder="017" value="<?php echo e($data->mobile_no); ?>"> </div>
                            </div>
                </div>
                <div class="col-md-7">
                        <div class="row">
                            <div class="col-md-6">
                                    <div class="formradio">
                                        <h3 style="font-style: italic;">SEX(choose one)*</h3>
                                        <br>
                                        <?php  $sexs=['MALE','FEMALE','OTHERS'];  ?>
                                        <?php $__currentLoopData = $sexs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="container">
                                            <input type="radio" name="sex" value="<?php echo e($sex); ?>" <?php if($sex==$data->sex): ?> checked <?php endif; ?>> <span class="checkmarkradio"></span><?php echo e($sex); ?> </label>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                            </div>
                            <div class="col-md-6">
                                <div class="religionsection">
                                    <div class="formradio">
                                        <h3 style="font-style: italic;">RELIGIONS(choose one)*</h3>
                                        <?php  $religions=['ISLAM','HINDU','CHRISTIAN','BUDDHA'];  ?>
                                        <?php $__currentLoopData = $religions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $religion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="container">
                                            <input type="radio" name="religion" value="<?php echo e($religion); ?>" <?php if($religions==$data->religion): ?> checked <?php endif; ?>> <span class="checkmarkradio"></span> <?php echo e($religion); ?></label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="maritalsection">
                                    <div class="formradio">
                                        <h3 style="font-style: italic;">MARITAL STATUS(choose one)*</h3>
                                        <?php  $marital_statuses=['MARRIED','UNMARRIED','DEVORSED'];  ?>
                                        <?php $__currentLoopData = $marital_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marital_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="container">
                                            <input type="radio" name="marital_status" value="<?php echo e($marital_status); ?>" <?php if($marital_status==$data->marital_status): ?> checked <?php endif; ?>> <span class="checkmarkradio"></span> <?php echo e($marital_status); ?></label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="nationalsection">
                                    <div class="formradio">
                                        <h3>NATIONALITY(choose one)*</h3>
                                        <?php  $nationalitys=['BANGLADESHI','OTHERS'];  ?>
                                        <?php $__currentLoopData = $nationalitys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nationality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="container">
                                            <input type="radio" name="nationality" value="<?php echo e($nationality); ?>" <?php if($nationality==$data->nationality): ?> checked <?php endif; ?>> <span class="checkmarkradio"></span><?php echo e($nationality); ?> </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="formradio">
                                        <h3 style="font-style: italic;">*Living Style</h3>
                                        <br>
                                        <label class="container">
                                            <input type="radio" name="living_style" value="DED" <?php if($data->living_style=='DED'): ?> checked <?php endif; ?>> <span class="checkmarkradio"></span> DED</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
                 <div class="col-md-9"></div>
                 <div class="col-md-1">
                    <a href="<?php echo e(url('member')); ?>" class="btn btn-lg btn-danger">Cancle</a>
                 </div>
                 <div class="col-md-2" style="padding-bottom: 25px;">
                 	<input type="submit"  value="Update" class="btn btn-lg btn-primary">
                 </div>
        </div>

         </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>