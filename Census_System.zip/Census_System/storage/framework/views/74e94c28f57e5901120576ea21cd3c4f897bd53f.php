<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-2">
          <?php echo $__env->make('layouts.side_navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-10 panel panel-default" style="padding: 10px">
        	<h3>Member Details</h3><hr>
        	<style type="text/css">
            td{padding: 10px;text-align: right;}
            .align_left{text-align: left;}
        </style>
        	<div class="col-md-6">
        	<table>
        		<tr>
        			<td>Name : </td>
        			<td class="align_left"><?php echo e($data->name); ?></td>
        		</tr><tr>
        			<td>NID : </td>
        			<td class="align_left"><?php echo e($data->nid); ?></td>
        		</tr><tr>
        			<td>BID : </td>
        			<td class="align_left"><?php echo e($data->bid); ?></td>
        		</tr><tr>
        			<td>Birth Date : </td>
        			<td class="align_left"><?php echo e($data->birth_date); ?></td>
        		</tr><tr>
        			<td>Occupation : </td>
        			<td class="align_left"><?php echo e($data->occupation); ?></td>
        		</tr><tr>
        			<td>Education : </td>
        			<td class="align_left"><?php echo e($data->education); ?></td>
        		</tr><tr>
        			<td>Relation With Khana : </td>
        			<td class="align_left"><?php echo e($data->relation_with_khana); ?></td>
        		</tr>
        	</table>
        	</div>

        	<div class="col-md-6">
        	<table>
        		<tr>
        			<td>Present Address : </td>
        			<td class="align_left"><?php echo e($data->present_address); ?></td>
        		</tr><tr>
        			<td>Mobile No : </td>
        			<td class="align_left"><?php echo e($data->mobile_no); ?></td>
        		</tr><tr>
        			<td>Sex : </td>
        			<td class="align_left"><?php echo e($data->sex); ?></td>
        		</tr><tr>
        			<td>Marital Status : </td>
        			<td class="align_left"><?php echo e($data->marital_status); ?></td>
        		</tr><tr>
        			<td>Religion : </td>
        			<td class="align_left"><?php echo e($data->religion); ?></td>
        		</tr><tr>
        			<td>Nationality : </td>
        			<td class="align_left"><?php echo e($data->nationality); ?></td>
        		</tr><tr>
        			<td>Living Style : </td>
        			<td class="align_left"><?php echo e($data->living_style); ?></td>
        		</tr>
        	</table>
        	</div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>