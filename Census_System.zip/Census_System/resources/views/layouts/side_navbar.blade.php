  <div class="panel panel-default">
            <nav id="sidebar">
             <ul class="list-unstyled components">
                <li> <a href="{{url('home')}}"><i class="fa fa-university" aria-hidden="true"></i> Home</a> </li> 
                <li> <a href="{{url('house_hold')}}"><i class="fa fa-university" aria-hidden="true"></i> HOUSE-HOLD</a> </li> 
                <li> <a href="{{url('member')}}"><i class="fa fa-university" aria-hidden="true"></i> Member</a> </li> 
            </ul>
            </nav>
</div>