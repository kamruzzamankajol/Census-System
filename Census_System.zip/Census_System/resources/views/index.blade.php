@extends('layouts.app')

@section('content')
   
    <div class="indexfirstdiv"> </div>
    <div class="maincontainer">
       <div class="container-fluid">
        <div class="leftview">
           <div class="row">
               
               <div class="col-md-6">
                   <div class="box">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellat voluptatibus amet ut voluptatem ducimus esse provident. Odio est aliquid in deleniti autem asperiores, omnis, unde esse architecto numquam molestiae vitae harum quam, dolores porro rem perferendis nulla recusandae magnam corporis consequatur. Veritatis labore quaerat blanditiis tempore dolor quasi est voluptas quo eius minima eaque, accusantium, sapiente laudantium, maxime quibusdam excepturi rem ut cupiditate sint recusandae molestias! Itaque commodi porro consequatur optio fugiat non laborum corrupti accusamus vero autem dolorum, veritatis mollitia repellat officiis suscipit omnis odit placeat nobis recusandae quam ducimus? Fugit itaque corporis, totam eum nostrum, saepe at eaque?</p>
            </div>
               </div>
               <div class="col-md-6">
                    <div class="box">
                    
                     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellat voluptatibus amet ut voluptatem ducimus esse provident. Odio est aliquid in deleniti autem asperiores, omnis, unde esse architecto numquam molestiae vitae harum quam, dolores porro rem perferendis nulla recusandae magnam corporis consequatur. Veritatis labore quaerat blanditiis tempore dolor quasi est voluptas quo eius minima eaque, accusantium, sapiente laudantium, maxime quibusdam excepturi rem ut cupiditate sint recusandae molestias! Itaque commodi porro consequatur optio fugiat non laborum corrupti accusamus vero autem dolorum, veritatis mollitia repellat officiis suscipit omnis odit placeat nobis recusandae quam ducimus? Fugit itaque corporis, totam eum nostrum, saepe at eaque?</p> </div>
               </div>
               <div class="col-md-6">
                    <div class="box">
                    
                     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellat voluptatibus amet ut voluptatem ducimus esse provident. Odio est aliquid in deleniti autem asperiores, omnis, unde esse architecto numquam molestiae vitae harum quam, dolores porro rem perferendis nulla recusandae magnam corporis consequatur. Veritatis labore quaerat blanditiis tempore dolor quasi est voluptas quo eius minima eaque, accusantium, sapiente laudantium, maxime quibusdam excepturi rem ut cupiditate sint recusandae molestias! Itaque commodi porro consequatur optio fugiat non laborum corrupti accusamus vero autem dolorum, veritatis mollitia repellat officiis suscipit omnis odit placeat nobis recusandae quam ducimus? Fugit itaque corporis, totam eum nostrum, saepe at eaque?</p> </div>
               </div>
               <div class="col-md-6">
                    <div class="box">
                    
                     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellat voluptatibus amet ut voluptatem ducimus esse provident. Odio est aliquid in deleniti autem asperiores, omnis, unde esse architecto numquam molestiae vitae harum quam, dolores porro rem perferendis nulla recusandae magnam corporis consequatur. Veritatis labore quaerat blanditiis tempore dolor quasi est voluptas quo eius minima eaque, accusantium, sapiente laudantium, maxime quibusdam excepturi rem ut cupiditate sint recusandae molestias! Itaque commodi porro consequatur optio fugiat non laborum corrupti accusamus vero autem dolorum, veritatis mollitia repellat officiis suscipit omnis odit placeat nobis recusandae quam ducimus? Fugit itaque corporis, totam eum nostrum, saepe at eaque?</p> </div>
               </div>
               <div class="col-md-6">
                    <div class="box">
                    
                     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellat voluptatibus amet ut voluptatem ducimus esse provident. Odio est aliquid in deleniti autem asperiores, omnis, unde esse architecto numquam molestiae vitae harum quam, dolores porro rem perferendis nulla recusandae magnam corporis consequatur. Veritatis labore quaerat blanditiis tempore dolor quasi est voluptas quo eius minima eaque, accusantium, sapiente laudantium, maxime quibusdam excepturi rem ut cupiditate sint recusandae molestias! Itaque commodi porro consequatur optio fugiat non laborum corrupti accusamus vero autem dolorum, veritatis mollitia repellat officiis suscipit omnis odit placeat nobis recusandae quam ducimus? Fugit itaque corporis, totam eum nostrum, saepe at eaque?</p> </div>
               </div>
               <div class="col-md-6">
                    <div class="box">
                    
                     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellat voluptatibus amet ut voluptatem ducimus esse provident. Odio est aliquid in deleniti autem asperiores, omnis, unde esse architecto numquam molestiae vitae harum quam, dolores porro rem perferendis nulla recusandae magnam corporis consequatur. Veritatis labore quaerat blanditiis tempore dolor quasi est voluptas quo eius minima eaque, accusantium, sapiente laudantium, maxime quibusdam excepturi rem ut cupiditate sint recusandae molestias! Itaque commodi porro consequatur optio fugiat non laborum corrupti accusamus vero autem dolorum, veritatis mollitia repellat officiis suscipit omnis odit placeat nobis recusandae quam ducimus? Fugit itaque corporis, totam eum nostrum, saepe at eaque?</p> </div>
               </div>
               
           </div>
            
        </div>
        </div>
    </div>
    <div class="footer"> </div>
@endsection
